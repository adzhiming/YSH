<?php 
//说明支付宝配置接口文件
if(!defined('IN_WaiMai')) {
	exit('Access Denied');
}
 $setinfo = array(
        'name'=>'微信支付app',
        'apiname'=>'weixinapp',
        'logourl'=>'',
        'forpay'=>4,
  ); 
 $plugsdata =  array();
   
?>