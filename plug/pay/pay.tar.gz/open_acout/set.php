<?php 
//说明支付宝配置接口文件
if(!defined('IN_WaiMai')) {
	exit('Access Denied');
}
 $setinfo = array(
        'name'=>'余额支付',
        'apiname'=>'open_acout',
        'logourl'=>'',
        'forpay'=>0,
  ); 
 $plugsdata =  array();
   
?>